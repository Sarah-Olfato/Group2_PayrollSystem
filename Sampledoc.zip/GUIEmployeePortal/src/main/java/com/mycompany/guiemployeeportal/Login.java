/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guiemployeeportal;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author ajbab
 */
public class Login {
    private String User;
    private String Pass;
      
    public boolean EmployeeLogin() throws FileNotFoundException, IOException, CsvValidationException {
        //if the password corresponds to the user in the file it will allow users to be able to log in
        String csvFilename = "EmployeeAccounts.csv";
        try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] line;
           
           while((line = reader.readNext()) != null){
              if(line[0].equals(User)){
                return line[1].equals(Pass);
              }
            }
        }
      return false;
    }
    
    //setter
    public void setUsername(String u){
        User = u;
    }
    
    public void setPassword(char[] p){
        Pass = new String(p);
    }
}
