package com.mycompany.guiemployeeportal;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yssha
 */
public class NetSalary {
    private double SSS;
    private double Pagibig;
    private double Philhealth;
    private double TD;
    private double TI;
    private double WT;
    private double NetM;
    private double NetW;
    

    
    
    public void SSS(double MB){ // computes for  SSS
        if (MB <= 3250)
         { SSS = 135;}
      
        else if (MB <= 3750)
         { SSS = 157.50;}  
       
       else if (MB <= 4250)
         { SSS =  180.00;}  

       else if (MB <= 4750)
         { SSS = 202.50;}  
       
        else if (MB <= 5250)
         { SSS = 225.00;}  
       
       else if (MB <= 5750)
         { SSS = 247.50;}  
       
        else if (MB <= 6250)
         { SSS = 270;}  
        
        else if (MB <= 6750)
         { SSS = 292.50;}  
       
        else if (MB <= 7250)
         { SSS = 337.50;}  
        
        else if (MB <= 7750)
         { SSS = 337.50;}  
        
        else if (MB <= 8250)
         { SSS = 360.00;}  
        
        else if (MB <= 8750)
         { SSS = 382.50;}
        
        else if (MB <= 9250)
         { SSS = 405.00;}
        
        else if (MB <= 9750)
         { SSS = 427.50;}
        
        else if (MB <= 10250)
         { SSS = 450.00;}
        
        else if (MB <= 10750)
         { SSS = 472.50;}
        
        else if (MB <= 11250)
         { SSS = 495.00;}
        
        else if (MB <= 11750)
         { SSS = 517.50;}
        
        else if (MB <= 12250)
         { SSS = 540.00;}
        
        else if (MB <= 12750)
         { SSS = 562.50;}
        
        else if (MB <= 13250)
         { SSS = 585.00;}
        
        else if (MB <= 13750)
         { SSS = 607.50;}
        
        else if (MB <= 14250)
         { SSS = 630.00;}
        
        else if (MB <= 14750)
         { SSS = 652.50;}
        
        else if (MB <= 15250)
         { SSS = 675.00;}
        
        else if (MB <= 15750)
         { SSS = 697.50;}
        
        else if (MB <= 16250)
         { SSS = 720.00;}
        
        else if (MB <= 16750)
         { SSS = 742.50;}
        
        else if (MB <= 17250)
         { SSS = 765.00;}
        
        else if (MB <= 17750)
         { SSS = 787.50;}
        
        else if (MB <= 18250)
         { SSS = 810.00;}
        
        else if (MB <= 18750)
         { SSS = 832.50;}
        
        else if (MB <= 19250)
         { SSS = 855.00;}
        
        else if (MB <= 19750)
         { SSS = 877.50;}
        
        else if (MB <= 20250)
         { SSS = 900.00;}
        
        else if (MB <= 20750)
         { SSS = 922.50;}
        
        else if (MB <= 21250)
         { SSS = 945.00;}
        
        else if (MB <= 21750)
         { SSS = 967.50;}
        
        else if (MB <= 22250)
         { SSS = 990.00;}
        
        else if (MB <= 22750)
         { SSS = 1012.50;}
        
        else if (MB <= 23250)
         { SSS = 1035.00;}
        
        else if (MB <= 23750)
         { SSS = 1057.50;}
         
        else if (MB <= 24250)
         { SSS = 1080.00;}
        
        else if (MB <= 24750)
         { SSS = 1102.50;}
        
        else 
         { SSS = 1125.00;}
     }
    
    public void Philhealth(double MB){ // computes for Philhealth
        Philhealth = (MB * 0.03)/2;
     }
     
    public void Pagibig(double MB){ //computes for Pagibig          
         if(MB <1000) {
            Pagibig = 0;}
         
         else if(MB <=1500) {
            Pagibig = MB*0.03;}
         
         else {
            Pagibig = MB*0.04;}
              
       if(Pagibig >100) {
            Pagibig = 100;} //Pagibig contribution maximum amount is 100
    }
    
    public void Taxable (double MB){
        TD = SSS + Philhealth + Pagibig; //computes for the total deduction
        TI = MB - TD; //computes for tacable income
     }   
    
    public void withholding(double MB){ //computes for withholding tac
       if(MB <=20832) {
            WT = 0;}
         
         else if(MB <33333) {
            WT = (TI-20833)*0.2;}
         
         else if(MB <66667) {
            WT = ((TI-33333)*0.25)+2500;}
         
         else if(MB <166667) {
            WT = ((TI-66667)*0.30)+10833;}
         
         else if(MB <666667) {
            WT = ((TI-166667)*0.32)+40833.33;}
         
         else {
            WT = ((TI-666667)*0.35)+200833.33;}          
       }
          
    public void NetMonthly(){ //computes for Monthly Salary with deductions
        NetM = TI - WT;
       }
       
    public void NetWeekly(){ //computes for net weekly salary 
        NetW = NetM/4;
       }
    
    //getter of variables
    public String getnetw(){
       return String.format("%.2f",NetW);
   }
    public String getnetm(){
       return String.format("%.2f",NetM);
   }
     public String getSSS(){
       return String.format("%.2f", SSS);
   }
      public String getPhilhealth(){
       return String.format("%.2f",Philhealth);
   }
       public String getPagibig(){
       return String.format("%.2f",Pagibig);
   }
        public String getTD(){
       return String.format("%.2f",TD);
   }
        public String getTI(){
       return String.format("%.2f",TI);
   }
         public String getWT(){
       return String.format("%.2f",WT);
   }
}
