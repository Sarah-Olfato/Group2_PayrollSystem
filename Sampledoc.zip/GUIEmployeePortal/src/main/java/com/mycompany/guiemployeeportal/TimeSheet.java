package com.mycompany.guiemployeeportal;


import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yssha
 */
public class TimeSheet {
    public double Thr;

     public DefaultTableModel Timesheet (String en, int month) throws FileNotFoundException, IOException, CsvValidationException{
        //Creates a table to display the Timesheet of the Employees per month
         DefaultTableModel TS;
         String CSVFilename = "Timesheet.csv";
         CSVReader Reader = new CSVReader(new FileReader(CSVFilename));
         String[] Information = Reader.readNext();
         TS = new DefaultTableModel(Information,0);
         String[] Data;
         
         double hr = 0;
         
         while((Data = Reader.readNext()) != null){
          if (Data[0].equals(en) && Integer.parseInt(Data[1]) == month){
             TS.addRow(Data);
             
             hr += Double.parseDouble(Data[6]); //sum of all the data in column 7
            }
          Thr = hr;
         }
         return TS;
    }
     
     //set the Total hrs worked for the month
     public void setThr(double hr){   
     Thr = hr;
     }
     //getter for Total hrs worked
     public double getThr(){
     return Thr;
     }
}
