/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guiemployeeportal;

import Frames.LoginSTART;

/**
 *
 * @author Yssha
 */
public class GUIEmployeePortal {

    public static void main(String[] args) {  
        //Runs from the log in frame
        LoginSTART Log = new LoginSTART();
        Log.show();
        
    }
}
