/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guiemployeeportal;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Yssha
 */
public class Leave {
    
    private int days;
    private int SE;
    private int Vaca;
    private String EN;
    private String name;
    private String Date;
    private String Leave;
    
    public DefaultTableModel LeaveApp (String en, String leave) throws FileNotFoundException, IOException, CsvValidationException{
        //display a table on the leave filed 
        DefaultTableModel LA;
         String CSVFilename = "LeaveApplication.csv";
         CSVReader Reader = new CSVReader(new FileReader(CSVFilename));
         String[] Information = Reader.readNext();
         LA = new DefaultTableModel(Information,0);
         String[] form;
         while((form = Reader.readNext()) != null){
          if (form[0].equals(en) && form[4].equals(leave)){
             LA.addRow(form);
             days +=Integer.parseInt(form[3]); //sums up the total number of days of leave of the employee in column 4
            }
         }
         return LA;
    }
    
    public void File(String CSVFilename) throws FileNotFoundException, IOException, CsvValidationException{
        //adds the information to a new row to file for leave
        CSVReader Reader = new CSVReader(new FileReader(CSVFilename));
         String[] Information = Reader.readNext();
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVFilename, true))){
         String [] form = new String[5];           
                    form[0] = EN;
                    form[1] = name;
                    form[2] = Date;
                    form[3] = Integer.toString(days);
                    form[4] = Leave;
                Writer.writeNext(form); 
            }
        }
    
  
    //setters for the variables
     public void setEN(String en){
       EN = en;
     }
     public void setname(String n){
         name = n;
     }
     public void setdate(String d){
         Date = d;
     }
     public void setleave(String l){
         Leave = l;
     }
     public void setdays(int day){
         days = day;
     }
     
     //getter for the variables
     public String getEN(){
       return EN;
     }
     public String getname(){
         return name;
     }
     public int getdays(){
         return days;
     }
     public String getleave(){
         return Leave;
     }
     public String getdate(){
         return Date;
     }
     public int getleftSE(){
         SE = 5 - days;
         return SE;
     }
     public int getleftVaca(){
         Vaca = 10 - days;
         return Vaca;
     }
}
