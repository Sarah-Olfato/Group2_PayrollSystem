package com.mycompany.guiemployeeportal;

import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yssha
 */
public class GrossSalary { 
    public double GrossW; 
    public double NetW;
    public double MB;
       
    public void MB(double Rate){ 
//computes for the monthly basic salary
        MB = Rate*21*8;
    }
    
    public void Grossweekly(){ 
//computes for gross weekly salary
       GrossW = MB/4;
    } 
    
    //getter of variables
    public String getMB(){ 
       return String.format("%.2f",MB);
   }
  
    public String getgrossw(){
       return String.format("%.2f",GrossW);
   }
}
    
