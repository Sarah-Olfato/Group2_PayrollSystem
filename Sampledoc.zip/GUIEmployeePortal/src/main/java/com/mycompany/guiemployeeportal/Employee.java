package com.mycompany.guiemployeeportal;


import java.io.FileWriter;
import com.opencsv.CSVWriter;
import java.io.FileReader;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

public class Employee {   
    private String name;
    public String EN;
    private String birthday;
    private String LN;
    private String FN;
    private String Num;
    private String SSSno;
    private String Philhealthno;
    private String TINno;
    private String Pagibigno;
    public String Rate;
    
    public void CreateEmployeeFile(String CSVFilename)throws IOException{ 
      //set the first line and will be used to create the file
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVFilename, true))){
         String [] Information = new String [10];
            Information[0] = "Employee Number";
            Information[1] = "Last Name";
            Information[2] = "First Name";
            Information[3] = "Birthday";
            Information[4] = "Contact #";
            Information[5] = "SSS #";
            Information[6] = "Philhealth #";
            Information[7] = "TIN #";
            Information[8] = "Pagibig #";
           Information[9] = "Rate";
            Writer.writeNext(Information); //writes the first line in the file
        }
    }
    
    public void AddEmployeeFile(String CSVFilename)throws IOException{ 
       //adds new employees to the file
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVFilename, true))){
         String [] Details = new String[10];
           Details[0] = EN;
           Details[1] = LN;
           Details[2] = FN;
           Details[3] = birthday;           
           Details[4] = Num;
           Details[5] = SSSno;
           Details[6] = Philhealthno;
           Details[7] = TINno;
           Details[8] = Pagibigno;
           Details[9] = Rate;
           Writer.writeNext(Details); //adds new information after the last line
        }
    }
    
    public void SearchName(String CSVFilename)throws IOException, CsvValidationException{
        //search according to the last name of the user
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Details;
            while((Details = Reader.readNext()) != null){
                if (Details[1].equals(LN)){
                     EN = Details[0];
                     LN = Details[1];
                     FN = Details[2];
                     birthday = Details[3];           
                     Num  = Details[4];
                     SSSno = Details[5];
                     Philhealthno = Details[6];
                     TINno = Details[7];
                     Pagibigno = Details[8];
                     Rate = Details[9];
                }
            }
        }
    }
 
    public DefaultTableModel ShowAll (String CSVFilename) throws IOException, CsvValidationException {
        //read the file contents and display into a table
        DefaultTableModel Infos;
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Information = Reader.readNext();
            Infos = new DefaultTableModel(Information,0);
            String[] line;
            while((line = Reader.readNext()) != null){
                Infos.addRow(line);
            }
        }
        return Infos;
    }
    
    public void EditInfo(String CSVFilename) throws FileNotFoundException, IOException, CsvValidationException{
        //rewrites the information according to the edited information of the employee
        String temporaryfile = CSVFilename.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVFilename)); 
        String[] Details2;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Details2 = Reader.readNext()) != null){
                if (Details2[0].equals(EN)){
                    Details2[0] = EN;
                    Details2[1] = LN;
                    Details2[2] = FN;
                    Details2[3] = birthday;           
                    Details2[4] = Num;
                    Details2[5] = SSSno;
                    Details2[6] = Philhealthno;
                    Details2[7] = TINno;
                    Details2[8] = Pagibigno;
                    Details2[9] = Rate;
                }
                Writer.writeNext(Details2); //rewrites the information in the temporary file
            }
            Reader.close();
        }
        new File(CSVFilename).delete(); //deletes original file
        new File(temporaryfile).renameTo(new File(CSVFilename)); //replaces with temporary file
}
     public void DeleteEmployee(String CSVFilename) throws FileNotFoundException, IOException, CsvValidationException {
         //rewrites a file with a deleted row of the employee to be taken off
        String temporaryfile = CSVFilename.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVFilename));
        String[] line;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((line = reader.readNext()) != null){
                if(!line[0].equals(EN)){
                    writer.writeNext(line);
                }
            }
            reader.close();
        } finally {
            new File(CSVFilename).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVFilename)); //replaces file with temporary file
        }
    }
     
    //getter of variables
    public String getName(){
       return name;
   }
    
    public String getEN(){
       return EN;
   }
      
    public String getlastname(){
       return LN;
   }
    
    public String getfirstname(){
       return FN;
   }
    
    public String getBirthday(){
       return birthday;
   }
    
    public String getNumber(){
       return Num;
   }
    
    public String getSSSNo(){
       return SSSno;
   }
    
    public String getPhilhealthNo(){
       return Philhealthno;
   }
    
    public String getTINNo(){
       return TINno;
   }
    
    public String getPagibigNo(){
       return Pagibigno;
   }
    
    public String getRate(){
       return Rate;
   }
    
    //setter for variables
    public void setEN(String en){
       EN = en;
    }
    public void setLN(String ln){
       LN = ln;
    }
    public void setFN(String fn){
       FN = fn;
    }
    public void setBirthday(String b){
       birthday = b;
    } 
    public void setNumber(String n){
       Num = n;
    } 
    public void setSSSno(String s){
       SSSno = s;
    } 
    public void setPhilhealthno(String phil){
       Philhealthno = phil;
    } 
    public void setTINno(String t){
       TINno = t;
    } 
    public void setPagibigno(String pag){
       Pagibigno = pag;
    }
     public void setRate(String r){
       Rate = r;
    }
    }
      
  