/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

public class User {
    private String username;
    private String password;
    private String Access;
        

    public void setUsername(String u){
        username = u;
    } 
    public void setPassword(char[] p){
        password = new String(p);
    }
    public void setAccess(String a){
        Access = a;
    }    
    
    class SystemAdmin extends User{
    }
}
