/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Class;
import Frames.LogIn;

/**
 *
 * @author Yssha
 */
public class MyPortal {

    public static void main(String[] args) {
        long current=System.currentTimeMillis();  
        java.sql.Date date =new java.sql.Date(current); 
        System.out.println("Hello World!" + date);
        double time;
        double hrsin = 8;
        double minin = 41; 
        double hrsout = 17;
        double minout = 32;
        time = (hrsout+(minout /60)) - (hrsin+(minin /60));
        System.out.println("time"+ time);
        LogIn Log = new LogIn();
        Log.show();
    }
}
