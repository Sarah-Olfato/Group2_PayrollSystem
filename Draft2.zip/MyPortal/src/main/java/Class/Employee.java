/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

public class Employee {
    private String EmployeeID;
    private String firstName;
    private String lastName;
    private String name;
    private String birthday;
    private String address;
    private String phoneNumber;
    private String status;
    private String position;
    private String department;
    private String supervisor;
   
    public String getEmployeeID(){
       return EmployeeID;
   }
      
    public String getlastname(){
       return lastName;
   }
    
    public String getfirstname(){
       return firstName;
   }
    
    public String getBirthday(){
       return birthday;
   }
    
    public String getAddress(){
       return address;
   }
    
    public String getPhoneNumber(){
       return phoneNumber;
   }
    
    public String getStatus(){
       return status;
   }
    
    public String getPosition(){
       return position;
   }
    
    public String getDepartment(){
       return department;
   }
    public String getSupervisor(){
       return supervisor;
   }
    
    //setter for variables
    public void setEmployeeID(String eID){
       EmployeeID = eID;
   }
      
    public void setlastname(String ln){
       lastName = ln;
   }
    
    public void setfirstname(String fn){
       firstName = fn;
   } 
    
    public void setname(String fn, String ln){
        name = fn + ln;
    }
    
    public void setBirthday(String b){
       birthday = b;
   }
    
    public void setAddress(String add){
       address = add;
   }
    
    public void setPhoneNumber(String pn){
       phoneNumber = pn;
   }
    
    public void setStatus(String s){
       status = s;
   }
    
    public void setPosition(String p){
       position = p;
   }
    
    public void setDepartment(String d){
       department = d;
   }
    public void setSupervisor(String s){
       supervisor = s;
   }
    class HR extends Employee{
        
    }
    class PayrollManager extends Employee{
        
    }
    class Staff extends Employee{
    
    }
}
