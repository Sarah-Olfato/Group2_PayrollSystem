/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

public class Timesheet {
    private String date;
    private String TimeIn;
    private String TimeOut;
    private double WrkdHrs;
    private double overtime;
  
    public void setTimeIn(String hrs,String min){
        TimeIn = hrs + ":" + min;
    }
    public String getTimeIn(){
        return TimeIn;
    }
    public void setTimeOut(String hrs, String min){
        TimeOut = hrs + ":" + min;
    }
    public String getTimeOut(){
        return TimeOut;
    }        
    private void calculateWrkdHrs(int ho, int mo, int hi, int mi){
       WrkdHrs =(ho+(mo/60))-(hi+(mi/60));
    }
    public String getWrkdHrs(){
         return String.format("%.2f", WrkdHrs);
    }
    private void calculateOvertime(){
        overtime = WrkdHrs - 8;
    }
    private String getOvertime(){
       return String.format("%.2f",overtime);
    }
}
