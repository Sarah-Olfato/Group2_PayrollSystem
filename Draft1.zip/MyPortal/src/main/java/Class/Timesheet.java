/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author Yssha
 */
public class Timesheet {
    private String date;
    private int hrsIn;
    private int hrsOut;
    private int minIn;
    private int minOut;
    private int TimeIn;
    private double WrkdHrs;
    private double overtime;
  
    private void TimeIn(int hrs,int min){
       // TimeIn = hrs + ":" + min;
    }
    
    private void calculateWrkdHrs(){
     //  Hrs =  minOut - minIn
    }
    
}
