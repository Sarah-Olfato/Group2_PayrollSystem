/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author Yssha
 */

public class Request {
    private String requestType;
    private String date;
    private String status;
   
   public String getrequestType(){
       return requestType;
   }
           
   public void setRequtype(String rt){
       requestType = rt;
   }
   
    public java.sql.Date getcurrentdate(){
        long current=System.currentTimeMillis();  
        java.sql.Date Date =new java.sql.Date(current);
       return Date;
   }
    
  public void setDate (String d){
        date = d;
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String s){
        status = s;
    }
}

class Profile extends Request{
    private String employeeData;
    private String changeTo;
    
    public void setEmployeeData(String ed){
        employeeData = ed;
    }
    public void setchangeTo(String c2){
        changeTo = c2;
    }
    
class Leave extends Request{
    private String typeofLeave;
    private String startLeave;
    private String endLeave;
    private int numofDays;
    private int numSick;
    private int numEmergency;
    private int numVacation;
    
    public void settypeofLeave(String tL){
        typeofLeave = tL;
    }
    public String gettypeofLeave(){
        return typeofLeave;
    }
    public void setstartLeave(String mm, String dd, String yyyy){
        startLeave = mm + "/"+ dd + "/"+ yyyy;
    }
    public String getstartLeave(){
        return startLeave;
    }
    public void setendLeave(String mm, String dd, String yyyy){
        endLeave = mm + "/"+ dd + "/"+ yyyy;
    }
    public String getendLeave(){
        return endLeave;
    }
    public void setnumberofdays(int NoD){
        numofDays = NoD;
    }
    public int getnumberofdays(){
        return numofDays;
    }
    
    public void leavecalculation(){
        if (typeofLeave == "Sick"){
            numSick = 5 - numofDays;
        }
        if (typeofLeave == "Emergency"){
            numEmergency = 5 - numofDays;
        }
        if (typeofLeave == "Vacation"){
            numVacation = 10 - numofDays;
        }
    }
}

class Overtime extends Request{
    String overtimeDate;
    int numofOT;
    
    public void setOvertimeDate(String otD){
        overtimeDate = otD;
    }
    public String overtimeDate(){
        return overtimeDate;
    }
    
    public void numofOT(int OTh){
        numofOT = OTh;
    }
    public int numofOT(){
        return numofOT;
    }
}
}


