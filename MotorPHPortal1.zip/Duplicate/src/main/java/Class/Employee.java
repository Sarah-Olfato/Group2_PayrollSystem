/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Employee {

    protected String EmployeeID, firstName, lastName, fullName, birthday, address, phoneNumber;
    
    public String getEmployeeID(){
       return EmployeeID;
   }
    public String getlastname(){
       return lastName;
   }
    
    public String getfirstname(){
       return firstName;
   }
    
    public String getName(){
        return fullName;
    }
     
    public String getBirthday(){
       return birthday;
   }
    
    public String getAddress(){
       return address;
   }
    
    public String getPhoneNumber(){
       return phoneNumber;
   }
 
    //setter for variables
    public void setEmployeeID(String eID){
       EmployeeID = eID;
   }
      
    public void setlastname(String ln){
       lastName = ln;
   }
    
    public void setfirstname(String fn){
       firstName = fn;
   } 
    
    public void setName(String ln, String fn){
        fullName = ln + "," + fn;
    }
    public void setBirthday(String b){
       birthday = b;
   }
    
    public void setAddress(String add){
       address = add;
   }
    
    public void setPhoneNumber(String pn){
       phoneNumber = pn;
   }
}   


