/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

   public class Request extends Timesheet{
   
   private String requestType, status;
   private int requestID;
   
   public String getrequestType(){
       return requestType;
   }
   
    public int getrequestID(){
       return requestID++;
   }
   
   public void setRequestType(String rt){
       requestType = rt;
   }
   
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String s){
        status = s;
    }
    
     abstract class Requests{
        abstract void submitRequest(String CSVRequesttype);
        abstract void viewRequest(String CSVRequesttype);
        abstract void approveRequest(String CSVRequesttype);
        abstract void rejectRequest(String CSVRequesttype);
     }     

    class changeProfile extends Request{
        private String EmployeeData, changeTo;
         
        public void setEmployeeData(String ed){
            EmployeeData = ed;
        }
         public void setchangeTo(String c2){
           changeTo = c2;
        }
         
        void submitRequest(String CSVchangeProfile) throws IOException{
            try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVchangeProfile, true))){
            String [] Column = new String[6]; 
            Column[0] = Integer.toString(requestID);
            Column[1] = EmployeeID;
            Column[2] = date;
            Column[3] = EmployeeData;
            Column[4] = changeTo;
            Column[5] = "Pending";
            Writer.writeNext(Column);
            }
        }
        void approveRequest(String CSVchangeProfile)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVchangeProfile.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVchangeProfile)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[5] = "Approved";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVchangeProfile).delete();
        new File(temporaryfile).renameTo(new File(CSVchangeProfile)); 
}
        void rejectRequest(String CSVchangeProfile)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVchangeProfile.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVchangeProfile)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[5] = "Reject";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVchangeProfile).delete();
        new File(temporaryfile).renameTo(new File(CSVchangeProfile)); 
}          
         public DefaultTableModel viewRequest(String CSVchangeProfile) throws FileNotFoundException, IOException, CsvValidationException{
         DefaultTableModel ChangeRequest;
         CSVReader Reader = new CSVReader(new FileReader(CSVchangeProfile));
         String[] Information = Reader.readNext();
         ChangeRequest = new DefaultTableModel(Information,0);
         String[] Data;
         while((Data = Reader.readNext()) != null){
          if (Data[1]== EmployeeID){
             ChangeRequest.addRow(Data);
            }
         }
         return ChangeRequest;
    }   
    }
    

    class Leave extends Request{
        private String typeofLeave, startLeave, endLeave;
        private int numofDays, TotalLeave, daysLeft;
        
        public void settypeofLeave(String tL){
           typeofLeave = tL;
        }
        public String gettypeofLeave(){
           return typeofLeave;
        }
        public void setstartLeave(String mm, String dd, String yyyy){
          startLeave = mm + "/"+ dd + "/"+ yyyy;
        }
        public String getstartLeave(){
           return startLeave;
        }
        public void setendLeave(String mm, String dd, String yyyy){
          endLeave = mm + "/"+ dd + "/"+ yyyy;
        }
        public String getendLeave(){
          return endLeave;
        }
        public void setnumberofdays(int NoD){
          numofDays = NoD;
        }
        public String getnumberofdays(){
          return String.valueOf(numofDays);
        }
        public String getTotalLeave(){
          return String.valueOf(TotalLeave);
        }
        public String getdaysLeft(){
          return String.valueOf(daysLeft);
        }
    
        void submitRequest(String CSVLeave) throws IOException{
            try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVLeave, true))){
            String [] Column = new String[8]; 
            Column[0] = Integer.toString(requestID);
            Column[1] = EmployeeID;
            Column[2] = date;
            Column[3] = typeofLeave;
            Column[4] = startLeave;
            Column[5] = endLeave;
            Column[6] = Integer.toString(numofDays);
            Column[7] = "Pending";
            Writer.writeNext(Column);
            }    
        }
                void approveRequest(String CSVleave)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVleave.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVleave)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[7] = "Approved";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVleave).delete();
        new File(temporaryfile).renameTo(new File(CSVleave)); 
}
        void rejectRequest(String CSVleave)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVleave.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVleave)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[7] = "Reject";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVleave).delete();
        new File(temporaryfile).renameTo(new File(CSVleave)); 
}          
         public DefaultTableModel viewRequest(String CSVleave) throws FileNotFoundException, IOException, CsvValidationException{
         DefaultTableModel Leave;
         CSVReader Reader = new CSVReader(new FileReader(CSVleave));
         String[] Information = Reader.readNext();
         Leave = new DefaultTableModel(Information,0);
         String[] Data;
         while((Data = Reader.readNext()) != null){
          if (Data[1].equals(EmployeeID) && Data[3].equals(typeofLeave)){
             Leave.addRow(Data);
             
             TotalLeave+=Integer.parseInt(Data[6]); 
             if (typeofLeave == "Sick" || typeofLeave == "Emergency"){
                 daysLeft = 5 - TotalLeave;
             }
             else if(typeofLeave == "Vacation"){
                 daysLeft = 10 - TotalLeave;
             } 
             else{
                 daysLeft = 0;
             }
            }
         }
         return Leave;
    }   
    }
    class Overtime extends Request{
        private String OvertimeDate;
        private double numOfHrs;
        
        public void setOvertimeDate(String otD){
           OvertimeDate = otD;
        }
        public String overtimeDate(){
           return OvertimeDate;
        }
    
        public void setnumofOT(double OTh){
           numOfHrs = OTh;
        }
        public String getnumofOT(){
           return Double.toString(numOfHrs);
        }
        void submitRequest(String CSVOvertime) throws IOException{
            try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVOvertime, true))){
            String [] Column = new String[6]; 
            Column[0] = Integer.toString(requestID);
            Column[1] = EmployeeID;
            Column[2] = date;
            Column[3] = OvertimeDate;
            Column[4] = Double.toString(numOfHrs);
            Column[5] = "Pending";
            Writer.writeNext(Column);
            }
        }
                void approveRequest(String CSVovertime)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVovertime.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVovertime)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[5] = "Approved";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVovertime).delete();
        new File(temporaryfile).renameTo(new File(CSVovertime)); 
}
        void rejectRequest(String CSVovertime)  throws FileNotFoundException, IOException, CsvValidationException{
            String temporaryfile = CSVovertime.replace(".csv", ".tmp"); 
            CSVReader Reader = new CSVReader (new FileReader(CSVovertime)); 
             String[] Column;
          try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(requestID) && (Column[1]== EmployeeID)){
                    Column[5] = "Reject";
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVovertime).delete();
        new File(temporaryfile).renameTo(new File(CSVovertime)); 
}          
         public DefaultTableModel viewRequest(String CSVovertime) throws FileNotFoundException, IOException, CsvValidationException{
         DefaultTableModel Overtime;
         CSVReader Reader = new CSVReader(new FileReader(CSVovertime));
         String[] Information = Reader.readNext();
         Overtime = new DefaultTableModel(Information,0);
         String[] Data;
         while((Data = Reader.readNext()) != null){
          if (Data[1]== EmployeeID){
             Overtime.addRow(Data);
            }
         }
         return Overtime;
    }   
   }
   }


