/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

public class Finance extends Employee {
    private String payPeriod, SSSno, Pagibigno, Philhealthno, TIN, status;
    private double rate;
      
    public void setPayPeriod (String m, String y){
       payPeriod = m + "-" + y;
    }
    
    public String getPayPeriod(){
       return payPeriod;
    }
    
    public void setSSSno(String sss){
       SSSno = sss;
    }
    
    public String getSSSno(){
       return SSSno;
    }
    public void setPagibigno(String pagibig){
       Pagibigno = pagibig;
    }
    
    public String getPagibigno(){
       return Pagibigno;
    }
    public void setPhilhealthno(String philh){
       Philhealthno = philh;
    }
    
    public String getPhilhealthno(){
       return Philhealthno;
    }
    public void setTIN(String tin){
       TIN = tin;
    }
    
    public String getTIN(){
       return TIN;
    }
    
    public void setrate(Double r){
       rate = r;
    }
    
    public String getrate(){
       return String.format("%.2f",rate);
    }
    
    public void setstatus(String s){
        status = s;
    }    
    public String getstatus(){
        return status;
    }
    
class Salary extends Finance{
    private double basicSalary, TotalHrsWrkd, overtimePay, benefits, grossPay, totalDeductions,
           totalAllowance, netPay;
    
    public void calculatebasicSalary(){
        basicSalary = rate * 21 * 8;
    }
    
    public Double getbasicSalary(){
        return basicSalary;
    }
    
    public void calculateOvertimePay(Double ot){
        overtimePay = rate * 1.25 * ot;
    }    
    
    public Double getOvertiemPay(){
        return overtimePay;
    }
    
    public void getBenefits(Double b){
        benefits = b;
    }
    
    public String setBenefits(){
        return String.format("%.2f", benefits);
    }
    
    public void calculategross(Double Thrs){
        grossPay = (rate * Thrs) + overtimePay + benefits;
    }
    public String getGrossPay(){
        return String.format("%.2f", grossPay);
    }    
    
    public String getTotalDeduction(){
        return String.format("%.2f", totalDeductions);
    }
    public String getTotalAllowance(){
        return String.format("%.2f", totalAllowance);
    }
    
    public void calculateNet(){
        netPay = grossPay - totalDeductions + totalAllowance;
    }
    
    public String getNetPay(){
         return String.format("%.2f", netPay);  
    }
 class Deduction extends Salary{   
    private double SSS, Pagibig, Philhealth, taxableIncome, withholdingTax;
    
    public void calculateSSS(){ // computes for  SSS
        if (basicSalary <= 3250)
         { SSS = 135;}
      
        else if (basicSalary <= 3750)
         { SSS = 157.50;}  
       
       else if (basicSalary <= 4250)
         { SSS =  180.00;}  

       else if (basicSalary <= 4750)
         { SSS = 202.50;}  
       
        else if (basicSalary <= 5250)
         { SSS = 225.00;}  
       
       else if (basicSalary <= 5750)
         { SSS = 247.50;}  
       
        else if (basicSalary <= 6250)
         { SSS = 270;}  
        
        else if (basicSalary <= 6750)
         { SSS = 292.50;}  
       
        else if (basicSalary <= 7250)
         { SSS = 337.50;}  
        
        else if (basicSalary <= 7750)
         { SSS = 337.50;}  
        
        else if (basicSalary <= 8250)
         { SSS = 360.00;}  
        
        else if (basicSalary <= 8750)
         { SSS = 382.50;}
        
        else if (basicSalary <= 9250)
         { SSS = 405.00;}
        
        else if (basicSalary <= 9750)
         { SSS = 427.50;}
        
        else if (basicSalary <= 10250)
         { SSS = 450.00;}
        
        else if (basicSalary <= 10750)
         { SSS = 472.50;}
        
        else if (basicSalary <= 11250)
         { SSS = 495.00;}
        
        else if (basicSalary <= 11750)
         { SSS = 517.50;}
        
        else if (basicSalary <= 12250)
         { SSS = 540.00;}
        
        else if (basicSalary <= 12750)
         { SSS = 562.50;}
        
        else if (basicSalary <= 13250)
         { SSS = 585.00;}
        
        else if (basicSalary <= 13750)
         { SSS = 607.50;}
        
        else if (basicSalary <= 14250)
         { SSS = 630.00;}
        
        else if (basicSalary <= 14750)
         { SSS = 652.50;}
        
        else if (basicSalary <= 15250)
         { SSS = 675.00;}
        
        else if (basicSalary <= 15750)
         { SSS = 697.50;}
        
        else if (basicSalary <= 16250)
         { SSS = 720.00;}
        
        else if (basicSalary <= 16750)
         { SSS = 742.50;}
        
        else if (basicSalary <= 17250)
         { SSS = 765.00;}
        
        else if (basicSalary <= 17750)
         { SSS = 787.50;}
        
        else if (basicSalary <= 18250)
         { SSS = 810.00;}
        
        else if (basicSalary <= 18750)
         { SSS = 832.50;}
        
        else if (basicSalary <= 19250)
         { SSS = 855.00;}
        
        else if (basicSalary <= 19750)
         { SSS = 877.50;}
        
        else if (basicSalary <= 20250)
         { SSS = 900.00;}
        
        else if (basicSalary <= 20750)
         { SSS = 922.50;}
        
        else if (basicSalary <= 21250)
         { SSS = 945.00;}
        
        else if (basicSalary <= 21750)
         { SSS = 967.50;}
        
        else if (basicSalary <= 22250)
         { SSS = 990.00;}
        
        else if (basicSalary <= 22750)
         { SSS = 1012.50;}
        
        else if (basicSalary <= 23250)
         { SSS = 1035.00;}
        
        else if (basicSalary <= 23750)
         { SSS = 1057.50;}
         
        else if (basicSalary <= 24250)
         { SSS = 1080.00;}
        
        else if (basicSalary <= 24750)
         { SSS = 1102.50;}
        
        else 
         { SSS = 1125.00;}
     }
    
    public void calculatePhilhealth(){ // computes for Philhealth
        Philhealth = (basicSalary * 0.03)/2;
     }
     
    public void calculatePagibig(){ //computes for Pagibig          
         if(basicSalary <1000) {
            Pagibig = 0;}
         
         else if(basicSalary <=1500) {
            Pagibig = basicSalary *0.03;}
         
         else {
            Pagibig = basicSalary*0.04;}
              
       if(Pagibig >100) {
            Pagibig = 100;} //Pagibig contribution maximum amount is 100
    }
    
    public void calculateTaxable (){
        taxableIncome = basicSalary - (SSS + Philhealth + Pagibig); //computes for taxable income
     }   
    
    public void calculateWithholding(){ //computes for withholding tac
       if(basicSalary <= 20832) {
            withholdingTax = 0;}
         
         else if(basicSalary <33333) {
            withholdingTax = (taxableIncome-20833)*0.2;}
         
         else if(basicSalary <66667) {
            withholdingTax = ((taxableIncome-33333)*0.25)+2500;}
         
         else if(basicSalary <166667) {
            withholdingTax = ((taxableIncome-66667)*0.30)+10833;}
         
         else if(basicSalary <666667) {
            withholdingTax = ((taxableIncome-166667)*0.32)+40833.33;}
         
         else {
            withholdingTax = ((taxableIncome-666667)*0.35)+200833.33;}          
       }
          
        public void calculateTotalDeductions(){
            totalDeductions = SSS + Philhealth + Pagibig + withholdingTax; //computes for the total deduction
    }
        
    //getter of variables
     public String getSSS(){
       return String.format("%.2f", SSS);
   }
      public String getPhilhealth(){
       return String.format("%.2f",Philhealth);
   }
      public String getPagibig(){
       return String.format("%.2f",Pagibig);
   }
      public String getDeductions(){
       return String.format("%.2f",totalDeductions);
   }
      public String getTaxable(){
       return String.format("%.2f",taxableIncome);
   }
      public String getWithholding(){
       return String.format("%.2f",withholdingTax);
   }
    }
 class Allowance extends Finance{
   private double clothingAllowance, phoneAllowance, riceSubsidy;
   
   public void calculateTotalAllowance(){
       totalAllowance = clothingAllowance + phoneAllowance + riceSubsidy;
   }
   public double getClothing(){
       return clothingAllowance;
   }
   public void setClothing(double ca){
       clothingAllowance = ca;
   }
   public double getPhone(){
       return phoneAllowance;
   }
   public void setPhone(double pa){
       phoneAllowance = pa;
   }
   public void getRice(double rs){
       riceSubsidy = rs;
   }
 }
    }
}
