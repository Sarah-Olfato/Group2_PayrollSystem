/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;


public class HR extends Finance{ 
   private String position, status, supervisor;
   
    public String getStatus(){
       return status;
   }
    
    public String getPosition(){
       return position;
   }
    public String getSupervisor(){
       return supervisor;
   }
    
    public void setStatus(String s){
       status = s;
   }
    
    public void setPosition(String p){
       position = p;
   }
        
    public void setSupervisor(String s){
       supervisor = s;
   }
    
      public void AddAccount(String CSVAccount) throws IOException{
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVAccount, true))){
         String [] Column = new String[10]; 
         Column[0] = EmployeeID;
         Column[1] = lastName;
         Column[2] = firstName;
         Column[3] = birthday;
         Column[4] = address;
         Column[5] = phoneNumber;
         Column[6] = status;
         Column[7] = position;
         Column[9] = supervisor;
         Writer.writeNext(Column);
    }
    }
      
    public void DeleteAccount(String CSVEmployeeInfo) throws FileNotFoundException, IOException, CsvValidationException {
        String temporaryfile = CSVEmployeeInfo.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(CSVEmployeeInfo));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(EmployeeID)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(CSVEmployeeInfo).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVEmployeeInfo)); //replaces file with temporary file
        }
    }
           
    public void EditInfo(String CSVFilename) throws FileNotFoundException, IOException, CsvValidationException{
        String temporaryfile = CSVFilename.replace(".csv", ".tmp"); 
        CSVReader Reader = new CSVReader (new FileReader(CSVFilename)); 
        String[] Column;
        try(CSVWriter Writer = new CSVWriter(new FileWriter(temporaryfile, true))) {
            while((Column = Reader.readNext()) != null){
                if (Column[0].equals(EmployeeID)){
                    Column[0] = EmployeeID;
                    Column[1] = lastName;
                    Column[2] = firstName;
                    Column[3] = birthday;
                    Column[4] = address;
                    Column[5] = phoneNumber;
                    Column[6] = status;
                    Column[7] = position;
                    Column[9] = supervisor;
                }
                Writer.writeNext(Column); 
            }
            Reader.close();
        }
        new File(CSVFilename).delete();
        new File(temporaryfile).renameTo(new File(CSVFilename)); 
}
                   
    public DefaultTableModel ViewEmployeeList (String CSVFilename) throws IOException, CsvValidationException {
        
        DefaultTableModel Information;
        try(CSVReader Reader = new CSVReader(new FileReader(CSVFilename))){
            String[] Data = Reader.readNext();
            Information = new DefaultTableModel(Data,0);
            String[] line;
            while((line = Reader.readNext()) != null){
                Information.addRow(line);
            }
        }
        return Information;
    }
    
    }
