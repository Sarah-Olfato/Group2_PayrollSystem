/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SystemAdmin extends Employee {
   
    protected String email, password, access;
  
    public void changePassword(String p, String check) throws FileNotFoundException, IOException, CsvValidationException{
        String CSVAccount = "Accounts.csv";
        String temporaryfile = CSVAccount.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(temporaryfile));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(email) && p == check){
                    Data[1] = p;
                }
            }
            reader.close();
        } finally {
            new File(temporaryfile).delete(); 
            new File(temporaryfile).renameTo(new File(CSVAccount)); 
        }
    } 
    
       public void AddNewAccount() throws IOException{
        String CSVAccount = "Accounts.csv";
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVAccount, true))){
         String [] Column = new String[3];
         email = lastName + EmployeeID + "@MotorPH.com";
         password = firstName + EmployeeID;
         Column[0] = email;
         Column[1] = password;
         Column[2] = access;
         Writer.writeNext(Column); //adds new information after the last line
    }        
    }
       
     public void DeactivateAccount() throws FileNotFoundException, IOException, CsvValidationException {
        String CSVAccount = "Accounts.csv";
        String temporaryfile = CSVAccount.replace(".csv", ".tmp");
        CSVReader reader = new CSVReader(new FileReader(temporaryfile));
        String[] Data;
        try(CSVWriter writer = new CSVWriter(new FileWriter(temporaryfile, true))){
            while((Data = reader.readNext()) != null){
                if(!Data[0].equals(email)){
                    writer.writeNext(Data);
                }
            }
            reader.close();
        } finally {
            new File(temporaryfile).delete(); //deletes original file
            new File(temporaryfile).renameTo(new File(CSVAccount)); //replaces file with temporary file
        }
    } 
    

public class User extends SystemAdmin{
       
    public void setemail(String e){
        email = e;
    }
    
    public void setPassword(char[] p){
        password = new String(p);
    }
    
    public void setAccess(String a){
        access = a;
    }
    
    public boolean EmployeeLogin() throws FileNotFoundException, IOException, CsvValidationException {
        String csvFilename = "Accounts.csv";
        try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] account;
           
           while((account = reader.readNext()) != null){
              if(account[0].equals(email)){
                return account[1].equals(password);
              }
            }
        }
      return false;
    }
    
    public boolean changeAccess() throws FileNotFoundException, IOException, CsvValidationException {
        String csvFilename = "Accounts.csv";
        try(CSVReader reader = new CSVReader(new FileReader(csvFilename))){
            String[] account;           
           while((account = reader.readNext()) != null){
              if(account[0].equals(email) && account[2].equals(access)){
                return account[1].equals(password);
              }
            }
        }
      return false;
    }
}
}