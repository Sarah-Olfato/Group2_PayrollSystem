/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

public class Timesheet extends Employee{
    protected String date, TimeIn, TimeOut;
    protected double WrkdHrs,Overtime, Twrkd, Tot;
  
    public void CreateNewTSRecord(String CSVPayperiod)throws IOException{ 
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVPayperiod, true))){
         String [] Information = new String [6];
            Information [0] = "Date";
            Information[1] = "Employee ID";
            Information[2] = "TimeIn";
            Information[3] = "TimeOut";
            Information[4] = "Overtime";
            Information[5] = "Hours worked";
           Writer.writeNext(Information);
        }
    }
    
    public void AddTSRecord(String CSVPayperiod) throws IOException{
        try(CSVWriter Writer = new CSVWriter(new FileWriter(CSVPayperiod, true))){
         String [] Information = new String [6];
            Information[0] = date;
            Information[1] = EmployeeID;
            Information[2] = TimeIn;
            Information[3] = TimeOut;
            Information[4] = String.format("%.2f",Overtime);
            Information[5] = String.format("%.2f",WrkdHrs);
           Writer.writeNext(Information);
        }    
    }
    
    public DefaultTableModel viewTSRecord(String CSVPayPeriod) throws FileNotFoundException, IOException, CsvValidationException{
         DefaultTableModel Timesheet;
         CSVReader Reader = new CSVReader(new FileReader(CSVPayPeriod));
         String[] Information = Reader.readNext();
         Timesheet = new DefaultTableModel(Information,0);
         String[] Data;
         while((Data = Reader.readNext()) != null){
          if (Data[1].equals(EmployeeID)){
             Timesheet.addRow(Data);
             Twrkd += Double.parseDouble(Data[4]);
             Tot += Double.parseDouble(Data[5]); 
            }
         }
         return Timesheet;
    }
    
    public java.sql.Date getcurrentdate(){
        long current=System.currentTimeMillis();  
        java.sql.Date Date =new java.sql.Date(current);
       return Date;
   }
    
    public void setDate (String d){
        date = d;
    }  
    
    public void setTimeIn(String hrs,String min){
        TimeIn = hrs + ":" + min;
    }
    public String getTimeIn(){
        return TimeIn;
    }
    public void setTimeOut(String hrs, String min){
        TimeOut = hrs + ":" + min;
    }
    public String getTimeOut(){
        return TimeOut;
    }        
    public void calculateWrkdHrs(int ho, int mo, int hi, int mi){
       WrkdHrs =(ho+(mo/60))-(hi+(mi/60));
    }
    public String getWrkdHrs(){
         return String.format("%.2f", WrkdHrs);
    }
    private void calculateOvertime(){
        Overtime = WrkdHrs - 8;
    }
    private String getOvertime(){
       return String.format("%.2f",Overtime);
    }
}

     
