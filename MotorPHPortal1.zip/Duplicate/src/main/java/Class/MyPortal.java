/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Class;
import Frames.Login;

public class MyPortal {

    public static void main(String[] args) {
        Login Log = new Login();
        Log.show();
    }
}
